import { Component } from '@angular/core';

@Component({
  selector: 'app-content',
  templateUrl: './home.html'
})
export class HomeComponent {
  title = 'app works!';
}
