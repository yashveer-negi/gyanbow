import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.html'
})
export class HeaderComponent {
  title = 'app works!';
}
