import { Component } from '@angular/core';

@Component({
  selector: 'app-content',
  templateUrl: './login.html'
})
export class LoginComponent {
  title = 'app works!';
}
